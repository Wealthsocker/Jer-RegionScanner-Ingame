package net.mcreator.jerregionscanneringame.procedures;

import net.mcreator.jerregionscanneringame.configuration.JerRegionScannerIngameConfiguration;
import net.mcreator.jerregionscanneringame.JerRegionscannerIngameMod;

import java.io.IOException;
import java.io.File;

public class MoveFileToJERFolderProcedure {
	public static void execute() {
		File GenWorldJsonFile = new File("");
		File targetFile = new File("");
		GenWorldJsonFile = new File((JerRegionScannerIngameConfiguration.PATHTORS.get() + "" + File.separator + "output"), File.separator + ("world-gen" + ".json"));
		targetFile = new File((JerRegionScannerIngameConfiguration.PATHTOTHEJERFOLDER.get()), File.separator + ("world-gen" + ".json"));
		if (GenWorldJsonFile.exists()) {
			if (targetFile.exists()) {
				targetFile.delete();
			}
			try {
				org.apache.commons.io.FileUtils.moveFile(GenWorldJsonFile, new File((JerRegionScannerIngameConfiguration.PATHTOTHEJERFOLDER.get() + "" + File.separator + "world-gen.json")));
			} catch (IOException e) {
				JerRegionscannerIngameMod.LOGGER.error(e);
			}
		}
	}
}
