package net.mcreator.jerregionscanneringame.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.Checkbox;

import net.mcreator.jerregionscanneringame.configuration.JerRegionScannerIngameConfiguration;

import java.util.HashMap;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;
import java.io.BufferedWriter;

public class CreateCMDProcedure {
	public static void execute(Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		File CMDFile = new File("");
		CMDFile = new File((JerRegionScannerIngameConfiguration.PATHTORS.get()), File.separator + ("cmd" + ".bat"));
		if (!(guistate.containsKey("checkbox:overworld") && ((Checkbox) guistate.get("checkbox:overworld")).selected()) && !(guistate.containsKey("checkbox:end") && ((Checkbox) guistate.get("checkbox:end")).selected())
				&& !(guistate.containsKey("checkbox:nether") && ((Checkbox) guistate.get("checkbox:nether")).selected())) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(("§c" + (Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.button_create_cmd_feedback_error_line0").getString()))), false);
		} else {
			if (!CMDFile.exists()) {
				try {
					CMDFile.getParentFile().mkdirs();
					CMDFile.createNewFile();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
			try {
				FileWriter CMDFilewriter = new FileWriter(CMDFile, false);
				BufferedWriter CMDFilebw = new BufferedWriter(CMDFilewriter);
				{
					CMDFilebw.write("@echo off");
					CMDFilebw.newLine();
				}
				{
					CMDFilebw.write(("cd " + "\"" + JerRegionScannerIngameConfiguration.PATHTORS.get() + "\""));
					CMDFilebw.newLine();
				}
				{
					CMDFilebw.write(("region_scanner.exe --path " + "\"" + JerRegionScannerIngameConfiguration.PATHTOWORLD.get() + "\""));
					CMDFilebw.newLine();
				}
				if (guistate.containsKey("checkbox:overworld") && ((Checkbox) guistate.get("checkbox:overworld")).selected() && !(guistate.containsKey("checkbox:end") && ((Checkbox) guistate.get("checkbox:end")).selected())
						&& !(guistate.containsKey("checkbox:nether") && ((Checkbox) guistate.get("checkbox:nether")).selected())) {
					{
						CMDFilebw.write(" --dims minecraft:overworld");
						CMDFilebw.newLine();
					}
				} else if (guistate.containsKey("checkbox:nether") && ((Checkbox) guistate.get("checkbox:nether")).selected() && !(guistate.containsKey("checkbox:end") && ((Checkbox) guistate.get("checkbox:end")).selected())
						&& !(guistate.containsKey("checkbox:overworld") && ((Checkbox) guistate.get("checkbox:overworld")).selected())) {
					{
						CMDFilebw.write(" --dims minecraft:the_nether");
						CMDFilebw.newLine();
					}
				} else if (guistate.containsKey("checkbox:end") && ((Checkbox) guistate.get("checkbox:end")).selected() && !(guistate.containsKey("checkbox:nether") && ((Checkbox) guistate.get("checkbox:nether")).selected())
						&& !(guistate.containsKey("checkbox:overworld") && ((Checkbox) guistate.get("checkbox:overworld")).selected())) {
					{
						CMDFilebw.write(" --dims minecraft:the_end");
						CMDFilebw.newLine();
					}
				} else if (guistate.containsKey("checkbox:overworld") && ((Checkbox) guistate.get("checkbox:overworld")).selected() && !(guistate.containsKey("checkbox:end") && ((Checkbox) guistate.get("checkbox:end")).selected())
						&& guistate.containsKey("checkbox:nether") && ((Checkbox) guistate.get("checkbox:nether")).selected()) {
					{
						CMDFilebw.write(" --dims minecraft:overworld minecraft:the_nether");
						CMDFilebw.newLine();
					}
				} else if (guistate.containsKey("checkbox:overworld") && ((Checkbox) guistate.get("checkbox:overworld")).selected() && guistate.containsKey("checkbox:end") && ((Checkbox) guistate.get("checkbox:end")).selected()
						&& !(guistate.containsKey("checkbox:nether") && ((Checkbox) guistate.get("checkbox:nether")).selected())) {
					{
						CMDFilebw.write(" --dims minecraft:overworld minecraft:the_end");
						CMDFilebw.newLine();
					}
				} else {
					{
						CMDFilebw.write(" --dims minecraft:overworld minecraft:the_nether minecraft:the_end");
						CMDFilebw.newLine();
					}
				}
				CMDFilebw.close();
				CMDFilewriter.close();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal((Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.button_create_cmd_feedback_line0").getString() + "" + ("cmd" + ".bat")
						+ Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.button_create_cmd_feedback_line1").getString())), false);
		}
	}
}
