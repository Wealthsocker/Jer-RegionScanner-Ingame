package net.mcreator.jerregionscanneringame.procedures;

import net.mcreator.jerregionscanneringame.configuration.JerRegionScannerIngameConfiguration;

import java.io.IOException;
import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class CreateReagionScannerWorldGenProcedure {
	public static void execute() {
		File GenWorldJsonFile = new File("");
		try {
			// Pfad zur Batch-Datei
			File cmdFile = new File(JerRegionScannerIngameConfiguration.PATHTORS.get(), "cmd.bat");
			// ProzessBuilder zum Starten der Batch-Datei im Verzeichnis des CMD-Files
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", cmdFile.getAbsolutePath());
			builder.directory(cmdFile.getParentFile()); // Arbeitsverzeichnis setzen
			Process process = builder.start();
			// Ausgabe-Reader (Standardausgabe)
			Thread stdoutReader = new Thread(() -> {
				try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
					String line;
					while ((line = reader.readLine()) != null) {
						System.out.println("[OUT] " + line); // oder logge es per LOGGER
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			// Fehlerausgabe-Reader
			Thread stderrReader = new Thread(() -> {
				try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
					String line;
					while ((line = reader.readLine()) != null) {
						System.err.println("[ERR] " + line); // oder logge es per LOGGER
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			// Threads starten
			stdoutReader.start();
			stderrReader.start();
			// Auf Prozessende warten
			int exitCode = process.waitFor();
			// Warten bis die Ausgabethreads fertig sind
			stdoutReader.join();
			stderrReader.join();
			System.out.println("Prozess beendet mit Code: " + exitCode);
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
		MoveFileToJERFolderProcedure.execute();
	}
}
