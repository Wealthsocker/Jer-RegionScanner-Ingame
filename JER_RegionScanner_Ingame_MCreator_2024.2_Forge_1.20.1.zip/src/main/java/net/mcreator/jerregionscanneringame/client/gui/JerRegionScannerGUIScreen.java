package net.mcreator.jerregionscanneringame.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.jerregionscanneringame.world.inventory.JerRegionScannerGUIMenu;
import net.mcreator.jerregionscanneringame.network.JerRegionScannerGUIButtonMessage;
import net.mcreator.jerregionscanneringame.JerRegionscannerIngameMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class JerRegionScannerGUIScreen extends AbstractContainerScreen<JerRegionScannerGUIMenu> {
	private final static HashMap<String, Object> guistate = JerRegionScannerGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Checkbox overworld;
	Checkbox nether;
	Checkbox end;
	Button button_starte_regionscanner;
	Button button_create_cmd;

	public JerRegionScannerGUIScreen(JerRegionScannerGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = new ResourceLocation("jer_regionscanner_ingame:textures/screens/jer_region_scanner_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.label_header"), 33, 7, -16777216, false);
	}

	@Override
	public void init() {
		super.init();
		button_starte_regionscanner = Button.builder(Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.button_starte_regionscanner"), e -> {
			if (true) {
				JerRegionscannerIngameMod.PACKET_HANDLER.sendToServer(new JerRegionScannerGUIButtonMessage(0, x, y, z));
				JerRegionScannerGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 24, this.topPos + 133, 129, 20).build();
		guistate.put("button:button_starte_regionscanner", button_starte_regionscanner);
		this.addRenderableWidget(button_starte_regionscanner);
		button_create_cmd = Button.builder(Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.button_create_cmd"), e -> {
			if (true) {
				JerRegionscannerIngameMod.PACKET_HANDLER.sendToServer(new JerRegionScannerGUIButtonMessage(1, x, y, z));
				JerRegionScannerGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 60, this.topPos + 106, 63, 20).build();
		guistate.put("button:button_create_cmd", button_create_cmd);
		this.addRenderableWidget(button_create_cmd);
		overworld = new Checkbox(this.leftPos + 15, this.topPos + 25, 20, 20, Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.overworld"), false);
		guistate.put("checkbox:overworld", overworld);
		this.addRenderableWidget(overworld);
		nether = new Checkbox(this.leftPos + 15, this.topPos + 52, 20, 20, Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.nether"), false);
		guistate.put("checkbox:nether", nether);
		this.addRenderableWidget(nether);
		end = new Checkbox(this.leftPos + 15, this.topPos + 79, 20, 20, Component.translatable("gui.jer_regionscanner_ingame.jer_region_scanner_gui.end"), false);
		guistate.put("checkbox:end", end);
		this.addRenderableWidget(end);
	}
}
