package net.mcreator.jerregionscanneringame.init;

import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.mcreator.jerregionscanneringame.configuration.JerRegionScannerIngameConfiguration;
import net.mcreator.jerregionscanneringame.JerRegionscannerIngameMod;

@Mod.EventBusSubscriber(modid = JerRegionscannerIngameMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class JerRegionscannerIngameModConfigs {
	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, JerRegionScannerIngameConfiguration.SPEC, "JerRegionScannerIngame.toml");
		});
	}
}
