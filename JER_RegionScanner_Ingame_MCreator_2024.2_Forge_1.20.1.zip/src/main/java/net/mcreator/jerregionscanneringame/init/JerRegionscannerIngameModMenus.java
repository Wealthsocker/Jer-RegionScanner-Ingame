
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jerregionscanneringame.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.jerregionscanneringame.world.inventory.JerRegionScannerGUIMenu;
import net.mcreator.jerregionscanneringame.JerRegionscannerIngameMod;

public class JerRegionscannerIngameModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, JerRegionscannerIngameMod.MODID);
	public static final RegistryObject<MenuType<JerRegionScannerGUIMenu>> JER_REGION_SCANNER_GUI = REGISTRY.register("jer_region_scanner_gui", () -> IForgeMenuType.create(JerRegionScannerGUIMenu::new));
}
