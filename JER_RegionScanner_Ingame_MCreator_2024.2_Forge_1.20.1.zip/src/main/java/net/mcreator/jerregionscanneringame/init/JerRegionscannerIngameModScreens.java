
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jerregionscanneringame.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.jerregionscanneringame.client.gui.JerRegionScannerGUIScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JerRegionscannerIngameModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(JerRegionscannerIngameModMenus.JER_REGION_SCANNER_GUI.get(), JerRegionScannerGUIScreen::new);
		});
	}
}
