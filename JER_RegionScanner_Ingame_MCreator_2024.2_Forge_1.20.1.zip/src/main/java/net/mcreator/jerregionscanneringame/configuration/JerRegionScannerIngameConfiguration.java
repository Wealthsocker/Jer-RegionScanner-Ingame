package net.mcreator.jerregionscanneringame.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class JerRegionScannerIngameConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<String> PATHTORS;
	public static final ForgeConfigSpec.ConfigValue<String> PATHTOWORLD;
	public static final ForgeConfigSpec.ConfigValue<String> PATHTOTHEJERFOLDER;
	public static final ForgeConfigSpec.ConfigValue<Boolean> MESSAGE;
	static {
		BUILDER.push("JESI");
		PATHTORS = BUILDER.comment("This is the Path to your Region_Scanner.exe Folder").define("Region_Scanner_Path", "C:\\Users\\UserName\\Desktop\\region_scanner");
		PATHTOWORLD = BUILDER.comment("This is the Path to your Minecraft World Folder\nThis Path works only for Curseforge Launcher!").define("World_Path", "C:\\Users\\UserName\\curseforge\\minecraft\\Instances\\Forge 1.20.1\\saves\\Neue Welt");
		PATHTOTHEJERFOLDER = BUILDER.comment("This is the Path to the JER Folder -> 'config\\jeresources'\nIf it does not exist, simply create the folder named 'jeresources'\nThis folder is for the ‘world-gen.json’ file that Jer should use")
				.define("JER_Config_Folder", "C:\\Users\\UserName\\curseforge\\minecraft\\Instances\\Forge 1.20.1\\config\\jeresources");
		BUILDER.pop();
		BUILDER.push("JESI_Optional");
		MESSAGE = BUILDER.comment("Toggle this to show a chat message when entering a world, suggesting how to open the GUI").define("toggle_message", true);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
