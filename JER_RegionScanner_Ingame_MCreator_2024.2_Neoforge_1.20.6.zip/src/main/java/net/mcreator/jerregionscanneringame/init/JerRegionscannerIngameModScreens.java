
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jerregionscanneringame.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.jerregionscanneringame.client.gui.JerRegionScannerGUIScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JerRegionscannerIngameModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(JerRegionscannerIngameModMenus.JER_REGION_SCANNER_GUI.get(), JerRegionScannerGUIScreen::new);
	}
}
