
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jerregionscanneringame.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.jerregionscanneringame.world.inventory.JerRegionScannerGUIMenu;
import net.mcreator.jerregionscanneringame.JerRegionscannerIngameMod;

public class JerRegionscannerIngameModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, JerRegionscannerIngameMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<JerRegionScannerGUIMenu>> JER_REGION_SCANNER_GUI = REGISTRY.register("jer_region_scanner_gui", () -> IMenuTypeExtension.create(JerRegionScannerGUIMenu::new));
}
