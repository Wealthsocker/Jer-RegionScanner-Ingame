package net.mcreator.jerregionscanneringame.init;

import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.bus.api.SubscribeEvent;

import net.mcreator.jerregionscanneringame.configuration.JerRegionScannerIngameConfiguration;
import net.mcreator.jerregionscanneringame.JerRegionscannerIngameMod;

@EventBusSubscriber(modid = JerRegionscannerIngameMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class JerRegionscannerIngameModConfigs {
	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, JerRegionScannerIngameConfiguration.SPEC, "JerRegionScannerIngame.toml");
		});
	}
}
